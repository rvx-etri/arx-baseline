#ifndef __PRESSURE_SENSOR_H__
#define __PRESSURE_SENSOR_H__

void configure_pressure_sensor();
unsigned int read_pressure_sensor_value();

#endif
