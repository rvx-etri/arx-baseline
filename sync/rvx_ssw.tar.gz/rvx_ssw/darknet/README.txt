[INFO]
Darknet
https://github.com/AlexeyAB/darknet.git
commit a7e5976c1b8e0d826d064bebd58fce2a046f718c
Author: AlexeyAB <alexeyab84@gmail.com>
Date:   Thu May 9 22:47:23 2019 +0300
