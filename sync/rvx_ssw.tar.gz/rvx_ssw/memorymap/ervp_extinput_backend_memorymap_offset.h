#ifndef __ERVP_EXTINPUT_BACKEND_MEMORYMAP_OFFSET_H__
#define __ERVP_EXTINPUT_BACKEND_MEMORYMAP_OFFSET_H__



// reg ervp_extinput_inst
#define BW_ERVP_EXTINPUT_INST 77

// reg ervp_extinput_inst_num_count_m1
#define BW_ERVP_EXTINPUT_INST_NUM_COUNT_M1 32

// reg ervp_extinput_inst_num_input_m1
#define BW_ERVP_EXTINPUT_INST_NUM_INPUT_M1 8

#endif