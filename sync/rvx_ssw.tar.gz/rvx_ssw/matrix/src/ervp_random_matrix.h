#ifndef __ERVP_RANDOM_MATRIX_H__
#define __ERVP_RANDOM_MATRIX_H__

#include "ervp_matrix.h"

void generate_random_matrix(ErvpMatrixInfo *matrix_info, int min, int max);

#endif
